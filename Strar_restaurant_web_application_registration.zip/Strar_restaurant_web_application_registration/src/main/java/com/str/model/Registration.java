package com.str.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
@Entity
public class Registration {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private int id;
@NotNull(message = "First Name is Required" )
private String FirstName;
@NotNull(message = "Last Name is Required")
private String LastName;
@NotNull(message = "Address is Required")
private String Address;
@NotNull (message = "City Name is Required")
private String CityName;
@NotNull (message  = "Pin Code is Required")
private int pinCode;
@NotNull(message = "Mobile Number is Required")
private String MobileNumber;
@Email
private String email;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getFirstName() {
	return FirstName;
}
public void setFirstName(String firstName) {
	FirstName = firstName;
}
public String getLastName() {
	return LastName;
}
public void setLastName(String lastName) {
	LastName = lastName;
}
public String getAddress() {
	return Address;
}
public void setAddress(String address) {
	Address = address;
}
public String getCityName() {
	return CityName;
}
public void setCityName(String cityName) {
	CityName = cityName;
}
public int getPinCode() {
	return pinCode;
}
public void setPinCode(int pinCode) {
	this.pinCode = pinCode;
}
public String getMobileNumber() {
	return MobileNumber;
}
public void setMobileNumber(String mobileNumber) {
	MobileNumber = mobileNumber;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
@Override
public String toString() {
	return "Registration [id=" + id + ", FirstName=" + FirstName + ", LastName=" + LastName + ", Address=" + Address
			+ ", CityName=" + CityName + ", pinCode=" + pinCode + ", MobileNumber=" + MobileNumber + ", email=" + email
			+ "]";
}

}
