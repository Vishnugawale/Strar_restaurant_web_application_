package com.str.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
@Entity
public class Customer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@NotBlank(message = "firstname is required")
	private String firstname;
	@NotBlank(message = "Lastname is required")
	private String Lastname;
	@NotBlank(message = "Date is  required")
	private String Date;
	@NotBlank(message = "Mobailnu is  required")
	private String MobailNumber;
	@NotBlank(message = "City is  required")
	private String City;
	@NotBlank(message = "State is  required")
	private String State;
	@NotBlank(message = "Pincode is  required")
	private String Pincode;
	@NotBlank(message = "Address is  required")
	private String Address;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return Lastname;
	}
	public void setLastname(String lastname) {
		Lastname = lastname;
	}
	public String getDate() {
		return Date;
	}
	public void setDate(String date) {
		Date = date;
	}
	public String getMobailNumber() {
		return MobailNumber;
	}
	public void setMobailNumber(String mobailNumber) {
		MobailNumber = mobailNumber;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getPincode() {
		return Pincode;
	}
	public void setPincode(String pincode) {
		Pincode = pincode;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", firstname=" + firstname + ", Lastname=" + Lastname + ", Date=" + Date
				+ ", MobailNumber=" + MobailNumber + ", City=" + City + ", State=" + State + ", Pincode=" + Pincode
				+ ", Address=" + Address + "]";
	}

}
