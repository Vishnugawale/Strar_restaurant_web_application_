package com.str.service;



import java.util.Optional;

import com.str.model.Registration;

public interface RegistrationServiceI {
	public void  addRegistrationuser(Registration registration);
	public Optional<Registration> getregisteruser(int id);
	public void updateregisteruser(Registration registration);
	public void deleteregisteruser(int id);
}
