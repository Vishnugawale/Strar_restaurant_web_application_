package com.str.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.str.dao.CustomerDaoI;
import com.str.model.Customer;

@Service
public class CustomerServiceImpl implements CustomerServiceI {
	
	@Autowired
	private CustomerDaoI repository;

	@Override
	public void addCustomerData(Customer customer) {
		// TODO Auto-generated method stub
		repository.save(customer);
	}

	@Override
	public Optional<Customer> getCustomerdata(int id) {
		Optional<Customer> list = repository.findById(id);
		// TODO Auto-generated method stub
		return list;
	}

	@Override
	public void updateCustomerdata(Customer customer) {
		// TODO Auto-generated method stub
		repository.save(customer);
		
	}

	@Override
	public void deleteCustomerdata(int id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
		
	}

	@Override
	public List<Customer> findByfirstname(String firstname) {
		// TODO Auto-generated method stub
		List<Customer>list = repository.findByfirstname(firstname);
		return list;
	}

}
