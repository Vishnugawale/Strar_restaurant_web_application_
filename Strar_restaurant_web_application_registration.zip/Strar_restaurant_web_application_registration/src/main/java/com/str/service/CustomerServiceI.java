package com.str.service;

import java.util.List;
import java.util.Optional;

import com.str.model.Customer;

public interface CustomerServiceI {
	public void addCustomerData(Customer customer);
	public Optional<Customer> getCustomerdata(int id);
	public void updateCustomerdata(Customer customer);
	public void deleteCustomerdata(int id);
	public List<Customer>findByfirstname(String firstname);

}
