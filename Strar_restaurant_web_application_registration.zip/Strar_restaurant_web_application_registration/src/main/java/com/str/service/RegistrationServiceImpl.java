package com.str.service;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.str.dao.RegistrationDaoI;
import com.str.model.Registration;

@Service
public class RegistrationServiceImpl implements RegistrationServiceI {
	
	@Autowired
	private RegistrationDaoI repository;

	@Override
	public void addRegistrationuser(Registration registration) {
		// TODO Auto-generated method stub
		repository.save(registration);
		
	}

	@Override
	public Optional<Registration> getregisteruser(int id) {
		// TODO Auto-generated method stub
		Optional<Registration> set = repository.findById(id);
		return set;
	}

	@Override
	public void updateregisteruser(Registration registration) {
		// TODO Auto-generated method stub
		repository.save(registration);
		
	}

	@Override
	public void deleteregisteruser(int id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
		
	}

}
