package com.str.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.str.model.Customer;

@Repository
public interface CustomerDaoI extends JpaRepository<Customer, Integer> {
	public List<Customer>findByfirstname(String firstname);
	public List<Customer>findByCity(String city);
}
