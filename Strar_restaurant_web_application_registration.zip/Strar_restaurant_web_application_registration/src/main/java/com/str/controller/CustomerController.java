package com.str.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.str.model.Customer;
import com.str.service.CustomerServiceI;

@RestController
@RequestMapping("/customer")
public class CustomerController {
	@Autowired
	private CustomerServiceI service;
	
	@PostMapping("/add")
	public void addCustomerdata(@RequestBody Customer customer) {
		service.addCustomerData(customer);
	}
	
	@GetMapping("/getcustomer/{id}")
	public Optional<Customer> getCustomerdata(@PathVariable int id){
		Optional<Customer>list = service.getCustomerdata(id);
		return list;
	}
	
	@PutMapping("/updatecustomer/{id}")
	public void updateCustomerdata(@RequestBody Customer customer) {
		service.updateCustomerdata(customer);
	}
	
	@DeleteMapping("/deletecustomer/{id}")
	public void deleteCustomerdata(@PathVariable int id) {
		service.deleteCustomerdata(id);
	}
	@GetMapping("/findByfirstname/{firstname}")
	public List<Customer>findByfirstname(@PathVariable String firstname){
		List<Customer> list = service.findByfirstname(firstname);
		return list;
	}
	
	@RequestMapping("/findBycity/{city}")
	public List<Customer>findBycity(@PathVariable String city ){
		List<Customer>list = service.findByCity(city);
		return list;
	}
}
