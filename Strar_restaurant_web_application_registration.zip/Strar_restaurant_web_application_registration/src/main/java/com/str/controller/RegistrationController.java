package com.str.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.str.model.Registration;
import com.str.service.RegistrationServiceI;

@RestController
@RequestMapping("/registration")
public class RegistrationController {

	@Autowired
	private RegistrationServiceI service;
	
	@PostMapping("/add")
	public void addregistration(@Valid @RequestBody Registration registration) {
		service.addRegistrationuser(registration);
	}
	@GetMapping("/user/{id}")
	public Optional<Registration> getregisteruser(@PathVariable int id){
		Optional<Registration> set = service.getregisteruser(id);
		return set;
	}
	
	@PutMapping("/update/{id}")
	public void updateregisteruser(@RequestBody Registration registration) {
		service.updateregisteruser(registration);
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteregisteruser(@PathVariable int id) {
		service.deleteregisteruser(id);
	}
}
