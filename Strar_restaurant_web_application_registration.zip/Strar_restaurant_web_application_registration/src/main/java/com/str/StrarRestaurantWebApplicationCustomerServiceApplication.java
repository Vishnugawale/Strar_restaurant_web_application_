package com.str;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StrarRestaurantWebApplicationCustomerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StrarRestaurantWebApplicationCustomerServiceApplication.class, args);
	}

}
